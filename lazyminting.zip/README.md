# Advanced Sample Hardhat Project

This project demonstrates NFT LAZY MINTING.

lazy minitng is an important step for the NFT marketplace

smart contract and test cases are here
Try running some of the following tasks:

```shell
npx hardhat accounts
npx hardhat compile
npx hardhat clean
npx hardhat test

```

# Etherscan verification

To try out Etherscan verification, you first need to deploy a contract to an Ethereum network that's supported by Etherscan.


# Performance optimizations
